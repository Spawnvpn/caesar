def invert_dict(D2):
    inv = dict()
    for key in D2:
        val = D2[key]
        if val not in inv:
            inv[val] = [key]
        else:
            inv[val].append(key)
    return inv


def get_crypt_text(text, number):
    A = 'abcdefghijklmnopqrstuvwxyz'
    C = 0
    B = text
    N = number
    if not B:
        B = "Enter words"
    if not B.isalpha():
        return "Only letters"
    if not B.islower():
        B = B.lower()
    if not N:
        N = 0
    if not N.isdigit():
        return "Invalid displacement"
    N = int(N)
    if N < 0:
        N = abs(N)
    if N > 26:
        N %= 26
    D2 = {}
    K = []
    x = 0
    j = 0
    counter = []
    for i in A:
        C += 1
        D = {i: C}
        D2.update(D)

    for i in B:
        j += 1
        if i == " ":
            i == i.replace(' ', '')
            counter.append(j)
    #        print counter
            continue
        J = D2.get(i)
        K.append(J)

#    print invert_dict(D2)
    D2 = invert_dict(D2)
    Z = []
    l = 0
    for i in K:
        l += 1
        for m in counter:
            if m == l:
                Z += ' '
                l += 1
        v = K[x]
        v += N
        if v > 26:
            v -= 26
        result = D2.get(v)
        Z += result
        x += 1
    #    print Z
    crypted_text = ''.join(Z)
    return crypted_text


