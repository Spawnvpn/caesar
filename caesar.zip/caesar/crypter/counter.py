def symbol_count(code_text):
    s = code_text
    l = {}; m1 = 0; m2 = 0
    s = s.replace(' ', '')
    for i in s:
        k = s.count(i)
        if not i in l:
            l[i] = 0
        l[i] += 1
        s = s.split(i)
        t = s
        s = ''
        for j in t:
            if not j == i:
                s += j
    cort = l.items()
    list = []
    res = []
    for i in cort:
        res[:] = i
        list.append(res[:])
    return list
