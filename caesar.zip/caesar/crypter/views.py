from django.http import JsonResponse
from django.shortcuts import render
import logic
import counter


def index(request):
    text = request.POST.get("text")
    number = request.POST.get("number")
    if text and number is not None:
        logic.get_crypt_text(text, number)
        crypted_text = logic.get_crypt_text(text, number)
    else:
        crypted_text = ""
    context = {
        "caesar_text": crypted_text
    }
    return render(request, template_name="index.html", context=context)


def ajax_func(request):
    if request.is_ajax():
        text = request.POST.get("text")
        number = request.POST.get("number")
        if text and number >= 0:
            crypted_text = logic.get_crypt_text(text, number)
        else:
            crypted_text = text
        context = {
            "code_text": crypted_text
        }
        return JsonResponse(context)


def chart(request):
    if request.is_ajax():
        text = request.POST.get("text")
        number = request.POST.get("number")
        if text and number >= 0:
            crypted_text = logic.get_crypt_text(text, number)
        else:
            crypted_text = text
        code_text = counter.symbol_count(crypted_text)
        context = {
            "code_text": code_text
        }
        return JsonResponse(context)
