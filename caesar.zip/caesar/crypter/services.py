def foo(bar):
    return bar
